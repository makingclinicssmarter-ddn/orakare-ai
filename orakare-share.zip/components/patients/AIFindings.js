'use client'

import { useState } from 'react'

const CONDITION_COLORS = {
  caries: 'bg-amber-100 border-amber-400 text-amber-800',
  missing: 'bg-gray-100 border-gray-400 text-gray-600',
  rct: 'bg-teal-100 border-teal-400 text-teal-800',
  crown: 'bg-blue-100 border-blue-400 text-blue-800',
  fracture: 'bg-red-100 border-red-400 text-red-800',
  mobility: 'bg-orange-100 border-orange-400 text-orange-800',
  sensitivity: 'bg-purple-100 border-purple-400 text-purple-800',
  periapical: 'bg-rose-100 border-rose-400 text-rose-800',
  erupting: 'bg-cyan-100 border-cyan-400 text-cyan-800',
  healthy: 'bg-green-100 border-green-400 text-green-800',
}

const CONFIDENCE_COLORS = {
  high: 'text-green-600',
  medium: 'text-amber-600',
  low: 'text-gray-400',
}

const SEVERITY_COLORS = {
  high: 'bg-red-50 text-red-700 border-red-200',
  moderate: 'bg-amber-50 text-amber-700 border-amber-200',
  low: 'bg-gray-50 text-gray-500 border-gray-200',
}

const IMAGE_TYPES = [
  { value: 'intraoral_photo', label: 'Intraoral Photo' },
  { value: 'periapical', label: 'Periapical X-Ray' },
  { value: 'bitewing', label: 'Bitewing X-Ray' },
  { value: 'occlusal', label: 'Occlusal X-Ray' },
  { value: 'opg', label: 'OPG' },
]

const SYMPTOM_QUESTIONS = [
  { id: 'location', label: 'Which tooth or area is bothering you?', placeholder: 'e.g. lower right back tooth, upper front' },
  { id: 'duration', label: 'How long has it been?', placeholder: 'e.g. 3 days, 2 weeks, a month' },
  { id: 'painType', label: 'Type of pain or discomfort?', placeholder: 'e.g. sharp, dull, throbbing, sensitivity, none' },
  { id: 'trigger', label: 'What makes it worse?', placeholder: 'e.g. cold, hot, biting, spontaneous, nothing' },
  { id: 'swelling', label: 'Any swelling or discharge?', placeholder: 'e.g. mild swelling on gum, no swelling' },
]

function ImageSlot({ index, slot, onUpdate, onRemove }) {
  function handleFileChange(e) {
    const file = e.target.files[0]
    if (!file) return
    onUpdate(index, {
      ...slot,
      file,
      preview: URL.createObjectURL(file),
    })
  }

  return (
    <div className="border border-gray-200 rounded-xl p-3 space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium text-gray-500">Image {index + 1}</span>
        <button
          onClick={function() { onRemove(index) }}
          className="text-xs text-gray-300 hover:text-red-400 transition"
        >
          Remove
        </button>
      </div>

      {!slot.preview ? (
        <label className="block w-full cursor-pointer">
          <div className="border-2 border-dashed border-gray-200 rounded-lg p-4 text-center hover:border-indigo-300 transition">
            <p className="text-xs text-gray-400">Click to upload</p>
            <p className="text-xs text-gray-300 mt-0.5">JPG, PNG, WebP</p>
          </div>
          <input
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
          />
        </label>
      ) : (
        <div className="relative">
          <img
            src={slot.preview}
            alt={'Image ' + (index + 1)}
            className="w-full h-32 object-cover rounded-lg border border-gray-200"
          />
          <label className="absolute bottom-2 right-2 cursor-pointer">
            <span className="text-xs bg-white border border-gray-200 rounded px-2 py-1 text-gray-500 hover:bg-gray-50">
              Change
            </span>
            <input
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
            />
          </label>
        </div>
      )}

      {/* Image type */}
      <div>
        <label className="text-xs text-gray-400 mb-1 block">Type <span className="text-gray-300">(optional)</span></label>
        <div className="flex flex-wrap gap-1">
          {IMAGE_TYPES.map(function(type) {
            return (
              <button
                key={type.value}
                onClick={function() { onUpdate(index, { ...slot, imageType: type.value }) }}
                className={'text-xs px-2 py-1 rounded border transition ' + (
                  slot.imageType === type.value
                    ? 'bg-indigo-600 text-white border-indigo-600'
                    : 'bg-white text-gray-500 border-gray-200 hover:border-indigo-300'
                )}
              >
                {type.label}
              </button>
            )
          })}
        </div>
      </div>

      {/* Region / teeth */}
      <div>
        <label className="text-xs text-gray-400 mb-1 block">
          Teeth / region visible <span className="text-gray-300">(optional)</span>
        </label>
        <input
          type="text"
          value={slot.region || ''}
          onChange={function(e) { onUpdate(index, { ...slot, region: e.target.value }) }}
          placeholder="e.g. 46, or lower right, or 14-17"
          className="w-full border border-gray-200 rounded-lg px-2 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
        />
      </div>
    </div>
  )
}

export default function AIFindings({ patient, visitId, onFindingsConfirmed, existingFindings = {} }) {
  const [slots, setSlots] = useState([{ file: null, preview: null, imageType: 'intraoral_photo', region: '' }])
  const [symptoms, setSymptoms] = useState({ location: '', duration: '', painType: '', trigger: '', swelling: '' })
  const [showSymptoms, setShowSymptoms] = useState(false)
  const [loading, setLoading] = useState(false)
  const [suggestions, setSuggestions] = useState([])
  const [decisions, setDecisions] = useState({})
  const [analysed, setAnalysed] = useState(false)

  function addSlot() {
    if (slots.length >= 5) return
    setSlots(function(prev) {
      return [...prev, { file: null, preview: null, imageType: 'intraoral_photo', region: '' }]
    })
  }

  function updateSlot(index, updated) {
    setSlots(function(prev) {
      const next = [...prev]
      next[index] = updated
      return next
    })
  }

  function removeSlot(index) {
    setSlots(function(prev) {
      if (prev.length === 1) return [{ file: null, preview: null, imageType: 'intraoral_photo', region: '' }]
      return prev.filter(function(_, i) { return i !== index })
    })
  }

  function updateSymptom(id, value) {
    setSymptoms(function(prev) { return { ...prev, [id]: value } })
  }

  const hasAnyImage = slots.some(function(s) { return s.file !== null })

  async function handleAnalyse() {
    if (!hasAnyImage) {
      alert('Please upload at least one image')
      return
    }
    setLoading(true)
    try {
      const formData = new FormData()
      formData.append('visitId', visitId)
      formData.append('symptoms', JSON.stringify(symptoms))

      const imageMeta = []
      slots.forEach(function(slot, index) {
        if (slot.file) {
          formData.append('image_' + index, slot.file)
          imageMeta.push({
            index,
            imageType: slot.imageType || 'intraoral_photo',
            region: slot.region || '',
          })
        }
      })
      formData.append('imageMeta', JSON.stringify(imageMeta))

      const res = await fetch('/api/patients/' + patient.id + '/ai-analysis', {
        method: 'POST',
        body: formData,
      })

      if (res.ok) {
        const data = await res.json()
        setSuggestions(data.suggestions || [])
        setAnalysed(true)
        const initialDecisions = {}
        data.suggestions.forEach(function(s, i) {
          initialDecisions[i] = 'pending'
        })
        setDecisions(initialDecisions)
      } else {
        alert('AI analysis failed. Please try again.')
      }
    } catch (e) {
      alert('Network error. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  function decide(index, decision) {
    setDecisions(function(prev) { return { ...prev, [index]: decision } })
  }

  function handleConfirmAll() {
    const confirmed = suggestions.filter(function(s, i) {
      return decisions[i] === 'confirmed'
    })
    if (onFindingsConfirmed) onFindingsConfirmed(confirmed)
  }

  const pendingCount = Object.values(decisions).filter(function(d) { return d === 'pending' }).length
  const confirmedCount = Object.values(decisions).filter(function(d) { return d === 'confirmed' }).length
  const rejectedCount = Object.values(decisions).filter(function(d) { return d === 'rejected' }).length

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-6 h-6 rounded-full bg-indigo-100 flex items-center justify-center">
            <span className="text-indigo-600 text-xs">✦</span>
          </div>
          <h2 className="text-sm font-medium text-gray-700">AI-assisted findings</h2>
          <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-600 border border-indigo-100">
            Doctor reviews each suggestion
          </span>
        </div>

        {/* Symptom questionnaire */}
        <div className="mb-4">
          <button
            onClick={function() { setShowSymptoms(function(p) { return !p }) }}
            className="flex items-center gap-2 text-xs text-indigo-600 hover:text-indigo-700 font-medium mb-2"
          >
            <span>{showSymptoms ? '▾' : '▸'}</span>
            Patient symptoms <span className="text-gray-400 font-normal">(optional — improves accuracy)</span>
          </button>
          {showSymptoms && (
            <div className="space-y-2 mb-3 bg-indigo-50 rounded-xl p-3 border border-indigo-100">
              {SYMPTOM_QUESTIONS.map(function(q) {
                return (
                  <div key={q.id}>
                    <label className="text-xs text-indigo-700 mb-0.5 block">{q.label}</label>
                    <input
                      type="text"
                      value={symptoms[q.id]}
                      onChange={function(e) { updateSymptom(q.id, e.target.value) }}
                      placeholder={q.placeholder}
                      className="w-full border border-indigo-200 rounded-lg px-2 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                    />
                  </div>
                )
              })}
            </div>
          )}
        </div>

        {/* Image slots */}
        <div className="space-y-3 mb-4">
          {slots.map(function(slot, index) {
            return (
              <ImageSlot
                key={index}
                index={index}
                slot={slot}
                onUpdate={updateSlot}
                onRemove={removeSlot}
              />
            )
          })}
        </div>

        {slots.length < 5 && (
          <button
            onClick={addSlot}
            className="w-full border border-dashed border-gray-200 text-gray-400 text-xs py-2 rounded-lg hover:border-indigo-300 hover:text-indigo-500 transition mb-4"
          >
            + Add another image ({slots.length}/5)
          </button>
        )}

        <button
          onClick={handleAnalyse}
          disabled={loading || !hasAnyImage}
          className="w-full bg-indigo-600 text-white py-2.5 rounded-lg text-sm font-medium hover:bg-indigo-700 transition disabled:opacity-50"
        >
          {loading ? 'Analysing...' : 'Analyse with AI'}
        </button>
      </div>

      {analysed && suggestions.length === 0 && (
        <div className="bg-white rounded-xl border border-gray-200 p-5 text-center">
          <p className="text-sm text-gray-500">No specific findings identified from these images.</p>
          <p className="text-xs text-gray-400 mt-1">Continue with manual chart marking.</p>
        </div>
      )}

      {suggestions.length > 0 && (
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-medium text-gray-700">
                {suggestions.length} suggestion{suggestions.length > 1 ? 's' : ''} from AI
              </h3>
              <p className="text-xs text-gray-400 mt-0.5">
                {confirmedCount} confirmed · {rejectedCount} rejected · {pendingCount} pending
              </p>
            </div>
            {pendingCount === 0 && confirmedCount > 0 && (
              <button
                onClick={handleConfirmAll}
                className="text-xs px-3 py-1.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition"
              >
                Add {confirmedCount} to chart
              </button>
            )}
          </div>

          <div className="space-y-3">
            {suggestions.map(function(suggestion, index) {
              const decision = decisions[index] || 'pending'
              const condColor = CONDITION_COLORS[suggestion.condition] || 'bg-gray-100 border-gray-300 text-gray-600'
              const confColor = CONFIDENCE_COLORS[suggestion.confidence] || 'text-gray-400'
              const sevColor = SEVERITY_COLORS[suggestion.severity] || SEVERITY_COLORS.low
              const doctorFinding = existingFindings[suggestion.tooth]
              const hasConflict = doctorFinding && doctorFinding !== suggestion.condition
              const hasMatch = doctorFinding && doctorFinding === suggestion.condition

              return (
                <div
                  key={index}
                  className={'rounded-lg border p-3 transition ' + (
                    decision === 'confirmed' ? 'border-green-300 bg-green-50' :
                    decision === 'rejected' ? 'border-gray-200 bg-gray-50 opacity-50' :
                    hasConflict ? 'border-amber-200 bg-amber-50' :
                    'border-gray-200 bg-white'
                  )}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                        <span className={'text-xs px-2 py-0.5 rounded-full border font-medium ' + condColor}>
                          Tooth {suggestion.tooth}
                        </span>
                        <span className={'text-xs px-2 py-0.5 rounded-full border font-medium ' + condColor}>
                          {suggestion.condition}
                        </span>
                        {suggestion.surface && (
                          <span className="text-xs px-2 py-0.5 rounded-full bg-gray-100 text-gray-600 border border-gray-200">
                            {suggestion.surface}
                          </span>
                        )}
                        <span className={'text-xs font-medium ' + confColor}>
                          {suggestion.confidence} confidence
                        </span>
                        {suggestion.severity && (
                          <span className={'text-xs px-2 py-0.5 rounded-full border font-medium ' + sevColor}>
                            {suggestion.severity} severity
                          </span>
                        )}
                        {hasConflict && (
                          <span className="text-xs px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200">
                            Doctor marked: {doctorFinding}
                          </span>
                        )}
                        {hasMatch && (
                          <span className="text-xs px-2 py-0.5 rounded-full bg-green-50 text-green-700 border border-green-200">
                            Matches doctor finding
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-gray-600 leading-relaxed">{suggestion.reasoning}</p>
                      {suggestion.differential && suggestion.differential.length > 0 && (
                        <p className="text-xs text-gray-400 mt-1">
                          Differential: {suggestion.differential.join(', ')}
                        </p>
                      )}
                      {suggestion.recommendedNext && (
                        <p className="text-xs text-indigo-600 mt-1">
                          Next: {suggestion.recommendedNext}
                        </p>
                      )}
                      {hasConflict && (
                        <p className="text-xs text-amber-600 mt-1">
                          Confirming this will not overwrite your finding. Update the chart manually if needed.
                        </p>
                      )}
                    </div>

                    {decision === 'pending' && (
                      <div className="flex gap-2 flex-shrink-0">
                        <button
                          onClick={function() { decide(index, 'confirmed') }}
                          className="w-7 h-7 rounded-full bg-green-100 text-green-600 hover:bg-green-200 transition text-sm flex items-center justify-center"
                        >
                          ✓
                        </button>
                        <button
                          onClick={function() { decide(index, 'rejected') }}
                          className="w-7 h-7 rounded-full bg-red-100 text-red-500 hover:bg-red-200 transition text-sm flex items-center justify-center"
                        >
                          ✕
                        </button>
                      </div>
                    )}

                    {decision === 'confirmed' && (
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <span className="text-xs text-green-600 font-medium">Confirmed</span>
                        <button onClick={function() { decide(index, 'pending') }} className="text-xs text-gray-400 hover:text-gray-600 ml-1">undo</button>
                      </div>
                    )}

                    {decision === 'rejected' && (
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <span className="text-xs text-gray-400 font-medium">Rejected</span>
                        <button onClick={function() { decide(index, 'pending') }} className="text-xs text-gray-400 hover:text-gray-600 ml-1">undo</button>
                      </div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>

          {pendingCount > 0 && (
            <p className="text-xs text-gray-400 mt-3 text-center">
              Review all suggestions before adding to chart
            </p>
          )}
        </div>
      )}
    </div>
  )
}